"""Shared LLM engine helpers."""
