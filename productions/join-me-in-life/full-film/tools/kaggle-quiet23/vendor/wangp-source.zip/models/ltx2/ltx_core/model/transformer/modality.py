from dataclasses import dataclass

import torch

from ...types import LatentStateRuntimeCache


@dataclass(frozen=True)
class PreparedConditioning:
    context: torch.Tensor
    projected_context: torch.Tensor | None = None


@dataclass(frozen=True)
class Modality:
    """
    Input data for a single modality (video or audio) in the transformer.
    Bundles the latent tokens, timestep embeddings, positional information,
    and text conditioning context for processing by the diffusion transformer.
    """

    latent: (
        torch.Tensor
    )  # Shape: (B, T, D) where B is the batch size, T is the number of tokens, and D is input dimension
    sigma: torch.Tensor  # Shape: (B,). Current sigma value for prompt/cross-attention AdaLN.
    timesteps: torch.Tensor  # Shape: (B, T) where T is the number of timesteps
    positions: (
        torch.Tensor
    )  # Shape: (B, 3, T) for video, where 3 is the number of dimensions and T is the number of tokens
    context: torch.Tensor | PreparedConditioning
    nag: dict | None = None
    enabled: bool = True
    context_mask: torch.Tensor | None = None
    attention_mask: torch.Tensor | None = None
    frame_indices: torch.Tensor | None = None
    runtime_cache: LatentStateRuntimeCache | None = None
    step_index: int | None = None
    sigma_schedule: torch.Tensor | None = None
